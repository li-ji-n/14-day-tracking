package com.example.wtc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
