// import 'dart:async';
// import 'dart:typed_data';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'map.dart';
// import 'mapOptions.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:location/location.dart';

// class Combine extends StatefulWidget {
//   @override
//   _CombineState createState() => _CombineState();
// }

// class _CombineState extends State<Combine> {

//   @override
//   Widget build(BuildContext context) {
//     return Stack(
//       children: [
//         Positioned(
//           child: MapPage(),
//         ),
//         Positioned(
//           top: 30,
//           child: MapOptions(),
//         ),
//       ],
//     );
//   }
// }
